import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// These utilities were moved to their own components
// Leaving these as stubs to avoid breaking imports, but they should not be used

// Cyberpunk color variations
export const cyberColors = {
  blue: "text-cyber-blue border-cyber-blue cyber-border",
  pink: "text-cyber-pink border-cyber-pink cyber-border-pink",
  purple: "text-cyber-purple border-cyber-purple",
};

// Generate cyberpunk gradients
export function cyberGradient(direction: string = "bg-gradient-to-r", colors: string[] = ["cyber-blue", "cyber-pink"]) {
  return `${direction} from-${colors[0]} to-${colors[1]}`;
}
