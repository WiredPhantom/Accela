import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { CyberButton } from "@/components/ui/cyber-button";
import { CyberCard } from "@/components/ui/cyber-card";
import { Loader2, PowerOff, Settings, ChevronRight } from "lucide-react";
import { Topic } from "@shared/schema";

export default function TopicsPage() {
  const { user, logoutMutation } = useAuth();
  const [_, navigate] = useLocation();

  const { data: topics, isLoading } = useQuery<Topic[]>({
    queryKey: ["/api/topics"],
  });

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    navigate("/login");
  };

  const handleTopicClick = (topicId: number) => {
    navigate(`/flashcards/${topicId}`);
  };

  const goToAdmin = () => {
    navigate("/admin");
  };

  return (
    <div className="min-h-screen p-4 relative scanline">
      <nav className="flex justify-between items-center mb-8 p-4 bg-cyber-dark cyber-border rounded-lg">
        <h1 className="text-3xl font-orbitron">
          <span className="text-cyber-blue">Neo</span><span className="text-cyber-pink">Mind</span>
        </h1>
        
        <div className="flex items-center space-x-4">
          <span className="text-sm opacity-80">Agent: <span className="text-cyber-blue">{user?.email?.split("@")[0] || "JXD-1192"}</span></span>
          <CyberButton onClick={handleLogout} variant="blue" className="py-2 px-4 text-sm">
            <PowerOff className="h-4 w-4 mr-2" /> LOGOUT
          </CyberButton>
        </div>
      </nav>
      
      <div className="mb-6">
        <h2 className="text-4xl font-orbitron mb-2">
          <span className="text-cyber-blue glitch-effect" data-text="NEURAL">NEURAL</span> <span className="text-cyber-pink glitch-effect" data-text="MODULES">MODULES</span>
        </h2>
        <p className="opacity-80">Select a neural enhancement module to begin training sequence</p>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-cyber-blue" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {topics && topics.length > 0 ? (
            topics.map((topic, index) => (
              <CyberCard 
                key={topic.id} 
                variant={index % 2 === 0 ? "blue" : "pink"}
                className="h-full cursor-pointer" 
                onClick={() => handleTopicClick(topic.id)}
              >
                <div className="flex justify-between items-start mb-4">
                  <h3 className={`text-xl font-orbitron ${index % 2 === 0 ? "text-cyber-blue" : "text-cyber-pink"}`}>
                    {topic.name}
                  </h3>
                  <span className={`text-xs border ${index % 2 === 0 ? "border-cyber-blue" : "border-cyber-pink"} px-2 py-1 rounded`}>
                    {topic.cardCount} CARDS
                  </span>
                </div>
                <p className="opacity-70 mb-4">{topic.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-xs opacity-60">Last accessed: {topic.lastAccessed ? new Date(topic.lastAccessed).toLocaleDateString() : "Never"}</span>
                  <span className={index % 2 === 0 ? "text-cyber-blue" : "text-cyber-pink"}>
                    <ChevronRight className="h-5 w-5" />
                  </span>
                </div>
              </CyberCard>
            ))
          ) : (
            <div className="col-span-full text-center p-8 bg-cyber-dark cyber-border rounded-lg">
              <p className="text-xl font-orbitron text-cyber-blue mb-2">No Neural Modules Found</p>
              <p className="opacity-70">Contact your system administrator to gain access to learning modules.</p>
            </div>
          )}
        </div>
      )}
      
      {user?.role === "ADMIN" && (
        <div className="fixed bottom-4 right-4">
          <CyberButton onClick={goToAdmin} variant="pink" className="p-4 rounded-full">
            <Settings className="h-5 w-5" />
          </CyberButton>
        </div>
      )}
    </div>
  );
}
