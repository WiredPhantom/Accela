import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { CyberButton } from "@/components/ui/cyber-button";
import { CardFlip } from "@/components/ui/card-flip";
import { CyberSwitch } from "@/components/ui/cyber-switch";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { Flashcard, Topic } from "@shared/schema";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";

export default function FlashcardPage() {
  const { topicId } = useParams<{ topicId: string }>();
  const [_, navigate] = useLocation();
  const [cardMode, setCardMode] = useState(true);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);

  const { data: topic, isLoading: isTopicLoading } = useQuery<Topic>({
    queryKey: [`/api/topics/${topicId}`],
  });

  const { data: flashcards, isLoading: isFlashcardsLoading } = useQuery<Flashcard[]>({
    queryKey: [`/api/topics/${topicId}/flashcards`],
  });

  const isLoading = isTopicLoading || isFlashcardsLoading;
  const currentFlashcard = flashcards && flashcards[currentCardIndex];
  const totalCards = flashcards?.length || 0;

  const goToTopics = () => {
    navigate("/");
  };

  const toggleViewMode = () => {
    setCardMode(!cardMode);
  };

  const prevCard = () => {
    if (currentCardIndex > 0) {
      setCurrentCardIndex(currentCardIndex - 1);
    }
  };

  const nextCard = () => {
    if (flashcards && currentCardIndex < flashcards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-cyber-blue" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 relative scanline">
      <nav className="flex justify-between items-center mb-8 p-4 bg-cyber-dark cyber-border rounded-lg">
        <div className="flex items-center space-x-4">
          <CyberButton onClick={goToTopics} variant="blue" className="py-2 px-4 text-sm">
            <ArrowLeft className="h-4 w-4 mr-2" /> MODULES
          </CyberButton>
          <h2 className="text-xl font-orbitron text-cyber-blue">{topic?.name || "Loading..."}</h2>
        </div>
        
        <div className="flex items-center space-x-4">
          <CyberSwitch 
            checked={cardMode}
            onCheckedChange={toggleViewMode}
            leftLabel="LIST VIEW"
            rightLabel="CARD VIEW"
          />
        </div>
      </nav>
      
      {cardMode ? (
        <div className="flex flex-col items-center justify-center">
          <div className="w-full max-w-2xl">
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm opacity-70">
                CARD <span>{currentCardIndex + 1}</span> OF <span>{totalCards}</span>
              </span>
              <div className="flex space-x-3">
                <CyberButton onClick={prevCard} variant="blue" className="p-2" disabled={currentCardIndex === 0}>
                  <ChevronLeft className="h-5 w-5" />
                </CyberButton>
                <CyberButton onClick={nextCard} variant="blue" className="p-2" disabled={currentCardIndex === totalCards - 1}>
                  <ChevronRight className="h-5 w-5" />
                </CyberButton>
              </div>
            </div>
            
            {currentFlashcard ? (
              <CardFlip 
                front={
                  <>
                    <h3 className="text-2xl font-orbitron text-cyber-blue mb-4">{currentFlashcard.front}</h3>
                    <div className="mt-6 opacity-70">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
                        <path d="M17 1l4 4-4 4"></path>
                        <path d="M3 11V9a4 4 0 0 1 4-4h14"></path>
                        <path d="M7 23l-4-4 4-4"></path>
                        <path d="M21 13v2a4 4 0 0 1-4 4H3"></path>
                      </svg>
                    </div>
                  </>
                }
                back={
                  <>
                    <h3 className="text-xl font-orbitron text-cyber-pink mb-4">{currentFlashcard.front}</h3>
                    <p className="text-lg text-center">{currentFlashcard.back}</p>
                  </>
                }
              />
            ) : (
              <div className="h-96 w-full bg-cyber-dark cyber-border rounded-lg flex items-center justify-center">
                <p className="text-cyber-blue text-xl">No flashcards available</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {flashcards && flashcards.length > 0 ? (
            flashcards.map((card, index) => (
              <div key={card.id} className="bg-cyber-dark cyber-border rounded-lg p-4 flex flex-col md:flex-row">
                <div className="flex-1 border-b md:border-b-0 md:border-r border-cyber-blue p-4">
                  <h3 className="text-xl font-orbitron text-cyber-blue mb-2">{card.front}</h3>
                </div>
                <div className="flex-1 p-4">
                  <p>{card.back}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-cyber-dark cyber-border rounded-lg p-8 text-center">
              <p className="text-xl font-orbitron text-cyber-blue">No flashcards available for this topic</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
