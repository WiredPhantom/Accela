import { useState, useRef, ChangeEvent } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CyberButton } from "@/components/ui/cyber-button";
import { CyberInput } from "@/components/ui/cyber-input";
import { CyberCard } from "@/components/ui/cyber-card";
import { AlertCircle, ArrowLeft, Edit, Trash, Upload } from "lucide-react";
import { Topic, Flashcard, User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Topic Form Schema
const topicSchema = z.object({
  name: z.string().min(2, "Topic name must be at least 2 characters"),
  description: z.string().min(5, "Description must be at least 5 characters"),
});

// Flashcard Form Schema
const flashcardSchema = z.object({
  front: z.string().min(2, "Front content is required"),
  back: z.string().min(2, "Back content is required"),
  topicId: z.string().min(1, "Topic selection is required"),
});

// User Form Schema
const userSchema = z.object({
  email: z.string().email("Invalid email address"),
  accessCode: z.string().min(6, "Access code must be at least 6 characters"),
  role: z.enum(["USER", "ADMIN"]),
});

export default function AdminPage() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedTopicId, setSelectedTopicId] = useState<string>("");
  const [bulkImportOpen, setBulkImportOpen] = useState(false);
  const [jsonParseError, setJsonParseError] = useState<string | null>(null);
  const [jsonData, setJsonData] = useState<any[] | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Data Queries
  const { data: topics, isLoading: isTopicsLoading } = useQuery<Topic[]>({
    queryKey: ["/api/topics"],
  });

  const { data: flashcards, isLoading: isFlashcardsLoading } = useQuery<Flashcard[]>({
    queryKey: ["/api/topics", selectedTopicId, "flashcards"],
    enabled: !!selectedTopicId,
  });

  const { data: users, isLoading: isUsersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
  });

  // Form Setup
  const topicForm = useForm<z.infer<typeof topicSchema>>({
    resolver: zodResolver(topicSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const flashcardForm = useForm<z.infer<typeof flashcardSchema>>({
    resolver: zodResolver(flashcardSchema),
    defaultValues: {
      front: "",
      back: "",
      topicId: "",
    },
  });

  const userForm = useForm<z.infer<typeof userSchema>>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      email: "",
      accessCode: "",
      role: "USER",
    },
  });

  // Mutations
  const bulkImportFlashcardsMutation = useMutation({
    mutationFn: async ({ topicId, flashcards }: { topicId: string, flashcards: Array<{front: string, back: string}> }) => {
      const res = await apiRequest("POST", `/api/topics/${topicId}/bulk-import`, flashcards);
      return await res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/topics", variables.topicId, "flashcards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      setJsonData(null);
      setBulkImportOpen(false);
      
      toast({
        title: "Success",
        description: `Successfully imported ${data.success} flashcards.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to import flashcards",
        variant: "destructive",
      });
    }
  });
  
  const addTopicMutation = useMutation({
    mutationFn: async (data: z.infer<typeof topicSchema>) => {
      const res = await apiRequest("POST", "/api/topics", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      topicForm.reset();
      toast({
        title: "Success",
        description: "Neural module added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTopicMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/topics/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      toast({
        title: "Success",
        description: "Neural module deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addFlashcardMutation = useMutation({
    mutationFn: async (data: z.infer<typeof flashcardSchema>) => {
      const res = await apiRequest("POST", `/api/topics/${data.topicId}/flashcards`, {
        front: data.front,
        back: data.back,
      });
      return await res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/topics", variables.topicId, "flashcards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      flashcardForm.reset();
      toast({
        title: "Success",
        description: "Flashcard added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteFlashcardMutation = useMutation({
    mutationFn: async ({ topicId, id }: { topicId: string; id: number }) => {
      await apiRequest("DELETE", `/api/topics/${topicId}/flashcards/${id}`);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/topics", variables.topicId, "flashcards"] });
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      toast({
        title: "Success",
        description: "Flashcard deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addUserMutation = useMutation({
    mutationFn: async (data: z.infer<typeof userSchema>) => {
      const res = await apiRequest("POST", "/api/users", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      userForm.reset();
      toast({
        title: "Success",
        description: "User added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Event Handlers
  const handleTopicSubmit = (data: z.infer<typeof topicSchema>) => {
    addTopicMutation.mutate(data);
  };

  const handleFlashcardSubmit = (data: z.infer<typeof flashcardSchema>) => {
    addFlashcardMutation.mutate(data);
  };

  const handleUserSubmit = (data: z.infer<typeof userSchema>) => {
    addUserMutation.mutate(data);
  };

  const handleTopicSelection = (value: string) => {
    setSelectedTopicId(value);
    flashcardForm.setValue("topicId", value);
  };
  
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setJsonParseError(null);
    setJsonData(null);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsedData = JSON.parse(content);
        
        // Validate the JSON structure
        if (!Array.isArray(parsedData)) {
          setJsonParseError("The uploaded JSON must be an array of flashcards");
          return;
        }
        
        // Validate each flashcard
        const isValid = parsedData.every((card: any) => 
          typeof card === 'object' && 
          typeof card.front === 'string' && 
          typeof card.back === 'string'
        );
        
        if (!isValid) {
          setJsonParseError("Each flashcard must have 'front' and 'back' string properties");
          return;
        }
        
        // Set the valid data
        setJsonData(parsedData);
      } catch (error) {
        setJsonParseError("Invalid JSON format. Please check your file and try again.");
      }
    };
    
    reader.readAsText(file);
  };
  
  const handleBulkImport = () => {
    if (!selectedTopicId || !jsonData || jsonData.length === 0) return;
    
    bulkImportFlashcardsMutation.mutate({
      topicId: selectedTopicId,
      flashcards: jsonData
    });
  };

  return (
    <div className="min-h-screen p-4 relative scanline">
      <nav className="flex justify-between items-center mb-8 p-4 bg-cyber-dark cyber-border-pink rounded-lg">
        <div className="flex items-center space-x-4">
          <CyberButton onClick={() => navigate("/")} variant="pink" className="py-2 px-4 text-sm">
            <ArrowLeft className="h-4 w-4 mr-2" /> BACK
          </CyberButton>
          <h2 className="text-xl font-orbitron text-cyber-pink">Admin Control System</h2>
        </div>
        
        <div className="flex items-center">
          <span className="text-sm text-cyber-pink">ADMIN CLEARANCE: <span className="text-white">LEVEL ALPHA</span></span>
        </div>
      </nav>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Topics Management */}
        <CyberCard variant="pink" className="p-5">
          <h3 className="text-xl font-orbitron text-cyber-pink mb-4">Neural Modules Management</h3>
          
          <div className="space-y-4 mb-6 max-h-64 overflow-y-auto pr-2">
            {isTopicsLoading ? (
              <div className="flex justify-center p-4">
                <div className="animate-spin h-5 w-5 text-cyber-pink" />
              </div>
            ) : topics && topics.length > 0 ? (
              topics.map(topic => (
                <div key={topic.id} className="flex items-center justify-between p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                  <span>{topic.name}</span>
                  <div className="flex space-x-2">
                    <button className="p-1 text-cyber-blue hover:text-white">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button 
                      className="p-1 text-red-500 hover:text-white"
                      onClick={() => deleteTopicMutation.mutate(topic.id)}
                    >
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                <p>No neural modules found</p>
              </div>
            )}
          </div>
          
          <Form {...topicForm}>
            <form onSubmit={topicForm.handleSubmit(handleTopicSubmit)} className="space-y-3">
              <FormField
                control={topicForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Module Name</FormLabel>
                    <FormControl>
                      <CyberInput 
                        placeholder="Enter new module name" 
                        variant="pink"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={topicForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Module Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter module description"
                        className="bg-cyber-gray border-cyber-pink cyber-border-pink text-white resize-none h-20"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <CyberButton 
                type="submit" 
                variant="pink"
                className="w-full py-2 text-sm"
                disabled={addTopicMutation.isPending}
              >
                {addTopicMutation.isPending ? "ADDING..." : "ADD NEW MODULE"}
              </CyberButton>
            </form>
          </Form>
        </CyberCard>
        
        {/* Flashcards Management */}
        <CyberCard variant="pink" className="p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-orbitron text-cyber-pink">Flashcards Management</h3>
            <CyberButton 
              variant="blue" 
              size="sm" 
              onClick={() => setBulkImportOpen(true)}
              disabled={!selectedTopicId}
              className="text-xs"
            >
              <Upload className="h-3 w-3 mr-1" /> BULK IMPORT
            </CyberButton>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm opacity-80 mb-2">Select Module</label>
            <Select 
              value={selectedTopicId} 
              onValueChange={handleTopicSelection}
            >
              <SelectTrigger className="w-full p-3 bg-cyber-gray border-cyber-pink cyber-border-pink text-white focus:outline-none">
                <SelectValue placeholder="Select a module" />
              </SelectTrigger>
              <SelectContent className="bg-cyber-dark border-cyber-pink">
                {topics && topics.map(topic => (
                  <SelectItem key={topic.id} value={topic.id.toString()}>{topic.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-4 mb-6 max-h-64 overflow-y-auto pr-2">
            {isFlashcardsLoading ? (
              <div className="flex justify-center p-4">
                <div className="animate-spin h-5 w-5 text-cyber-pink" />
              </div>
            ) : flashcards && flashcards.length > 0 ? (
              flashcards.map(card => (
                <div key={card.id} className="flex items-center justify-between p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                  <span className="truncate flex-1 pr-2">{card.front}</span>
                  <div className="flex space-x-2 flex-shrink-0">
                    <button className="p-1 text-cyber-blue hover:text-white">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button 
                      className="p-1 text-red-500 hover:text-white"
                      onClick={() => deleteFlashcardMutation.mutate({ topicId: selectedTopicId, id: card.id })}
                    >
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : selectedTopicId ? (
              <div className="text-center p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                <p>No flashcards found for this module</p>
              </div>
            ) : (
              <div className="text-center p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                <p>Select a module to view flashcards</p>
              </div>
            )}
          </div>
          
          <Form {...flashcardForm}>
            <form onSubmit={flashcardForm.handleSubmit(handleFlashcardSubmit)} className="space-y-3">
              <FormField
                control={flashcardForm.control}
                name="front"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Card Front</FormLabel>
                    <FormControl>
                      <CyberInput 
                        placeholder="Question" 
                        variant="pink"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={flashcardForm.control}
                name="back"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Card Back</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Answer"
                        className="bg-cyber-gray border-cyber-pink cyber-border-pink text-white resize-none h-24"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={flashcardForm.control}
                name="topicId"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <input type="hidden" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <CyberButton 
                type="submit" 
                variant="pink"
                className="w-full py-2 text-sm"
                disabled={addFlashcardMutation.isPending || !selectedTopicId}
              >
                {addFlashcardMutation.isPending ? "ADDING..." : "ADD NEW CARD"}
              </CyberButton>
            </form>
          </Form>
        </CyberCard>
        
        {/* User Management */}
        <CyberCard variant="pink" className="p-5">
          <h3 className="text-xl font-orbitron text-cyber-pink mb-4">User Access Management</h3>
          
          <div className="space-y-4 mb-6 max-h-64 overflow-y-auto pr-2">
            {isUsersLoading ? (
              <div className="flex justify-center p-4">
                <div className="animate-spin h-5 w-5 text-cyber-pink" />
              </div>
            ) : users && users.length > 0 ? (
              users.map(user => (
                <div key={user.id} className="flex items-center justify-between p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                  <div className="truncate pr-2">
                    <div>{user.email}</div>
                    <div className="text-xs opacity-70">Access Level: {user.role}</div>
                  </div>
                  <div className="flex space-x-2 flex-shrink-0">
                    <button className="p-1 text-cyber-blue hover:text-white">
                      <Edit className="h-4 w-4" />
                    </button>
                    <button 
                      className="p-1 text-red-500 hover:text-white"
                      onClick={() => deleteUserMutation.mutate(user.id)}
                    >
                      <Trash className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center p-3 border border-cyber-pink bg-cyber-gray bg-opacity-30 rounded">
                <p>No users found</p>
              </div>
            )}
          </div>
          
          <Form {...userForm}>
            <form onSubmit={userForm.handleSubmit(handleUserSubmit)} className="space-y-3">
              <FormField
                control={userForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Email</FormLabel>
                    <FormControl>
                      <CyberInput 
                        placeholder="user@neocorp.io" 
                        type="email"
                        variant="pink"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={userForm.control}
                name="accessCode"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Access Code</FormLabel>
                    <FormControl>
                      <CyberInput 
                        placeholder="Generate or enter code" 
                        variant="pink"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={userForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Access Level</FormLabel>
                    <Select 
                      value={field.value} 
                      onValueChange={field.onChange}
                    >
                      <SelectTrigger className="w-full p-3 bg-cyber-gray border-cyber-pink cyber-border-pink text-white focus:outline-none">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent className="bg-cyber-dark border-cyber-pink">
                        <SelectItem value="USER">User</SelectItem>
                        <SelectItem value="ADMIN">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <CyberButton 
                type="submit" 
                variant="pink"
                className="w-full py-2 text-sm"
                disabled={addUserMutation.isPending}
              >
                {addUserMutation.isPending ? "ADDING..." : "ADD NEW USER"}
              </CyberButton>
            </form>
          </Form>
        </CyberCard>
      </div>
      
      {/* Bulk Import Dialog */}
      <Dialog open={bulkImportOpen} onOpenChange={setBulkImportOpen}>
        <DialogContent className="bg-cyber-dark border-cyber-blue p-6 max-w-md w-full">
          <DialogHeader>
            <DialogTitle className="text-lg font-orbitron text-cyber-blue mb-2">
              Bulk Import Flashcards
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Upload a JSON file containing flashcards. The file should contain an array of objects with "front" and "back" properties.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 my-4">
            <div className="bg-black/20 p-3 border border-cyber-blue/40 rounded-md">
              <p className="text-xs text-gray-400 mb-2">Example JSON format:</p>
              <pre className="text-xs overflow-x-auto text-gray-300">
{`[
  {
    "front": "What is a neural network?",
    "back": "A computational model inspired by the human brain."
  },
  {
    "front": "What is encryption?",
    "back": "The process of encoding information."
  }
]`}
              </pre>
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm text-gray-300">
                Selected Topic: <span className="text-cyber-blue">{topics?.find(t => t.id.toString() === selectedTopicId)?.name || 'None'}</span>
              </label>
              
              <input
                type="file"
                accept=".json"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
              />
              
              <div className="flex flex-col gap-3">
                <CyberButton
                  type="button"
                  variant="blue"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full"
                >
                  <Upload className="h-4 w-4 mr-2" /> SELECT JSON FILE
                </CyberButton>
                
                {jsonData && (
                  <div className="bg-cyber-blue/10 p-3 rounded-md">
                    <p className="text-cyber-blue text-sm mb-1">Ready to import {jsonData.length} flashcards</p>
                    <p className="text-xs text-gray-400">The JSON file has been validated and is ready to be imported.</p>
                  </div>
                )}
                
                {jsonParseError && (
                  <div className="bg-red-900/20 p-3 rounded-md flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                    <p className="text-red-500 text-xs">{jsonParseError}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <CyberButton
              variant="pink"
              onClick={() => setBulkImportOpen(false)}
              className="mt-2"
            >
              CANCEL
            </CyberButton>
            <CyberButton
              variant="blue"
              onClick={handleBulkImport}
              disabled={!jsonData || bulkImportFlashcardsMutation.isPending}
              className="mt-2"
            >
              {bulkImportFlashcardsMutation.isPending ? "IMPORTING..." : "IMPORT FLASHCARDS"}
            </CyberButton>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
