import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CyberInput } from "@/components/ui/cyber-input";
import { CyberButton } from "@/components/ui/cyber-button";
import { useToast } from "@/hooks/use-toast";

const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  accessCode: z.string().min(6, "Access code must be at least 6 characters"),
});

export default function LoginPage() {
  const [_, navigate] = useLocation();
  const { loginMutation } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      accessCode: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof loginSchema>) => {
    setIsLoading(true);
    try {
      await loginMutation.mutateAsync(values);
      navigate("/");
    } catch (error) {
      toast({
        title: "Access Denied",
        description: "Invalid neural credentials. Authorization failed.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 relative scanline">
      <div className="absolute inset-0 opacity-20 z-0" style={{ 
        backgroundImage: "url('https://images.unsplash.com/photo-1493514789931-586cb221d7a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')", 
        backgroundSize: "cover", 
        backgroundPosition: "center" 
      }}></div>
      
      <div className="w-full max-w-md z-10">
        <div className="mb-8 text-center">
          <h1 className="text-5xl font-orbitron font-bold mb-2">
            <span className="text-cyber-blue glitch-effect" data-text="Neo">Neo</span><span className="text-cyber-pink glitch-effect" data-text="Mind">Mind</span>
          </h1>
          <p className="text-lg opacity-80">Neural Enhancement Optimization</p>
        </div>
        
        <div className="bg-cyber-dark p-6 rounded-lg cyber-border relative">
          <div className="absolute top-0 right-0 text-xs text-cyber-blue p-1 border-b border-l border-cyber-blue bg-cyber-dark">
            AUTH.SYS v2.0.77
          </div>

          <h2 className="text-2xl font-orbitron mb-6 text-cyber-blue">System Access</h2>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Neural ID</FormLabel>
                    <FormControl>
                      <CyberInput 
                        placeholder="user@neocorp.io" 
                        variant="blue"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="accessCode"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel className="block text-sm opacity-80">Access Code</FormLabel>
                    <FormControl>
                      <CyberInput 
                        type="password" 
                        placeholder="•••••••" 
                        variant="blue"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="pt-2">
                <CyberButton 
                  type="submit" 
                  className="w-full py-3 font-orbitron text-lg"
                  disabled={isLoading}
                >
                  {isLoading ? "INITIALIZING..." : "INITIALIZE ACCESS"}
                </CyberButton>
              </div>
              
              <div className="text-xs text-center mt-4 opacity-70">
                <p>Access restricted to authorized neural profiles.</p>
                <p>Unauthorized access attempts will be traced and neutralized.</p>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
