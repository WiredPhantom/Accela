import React from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export interface CyberCardProps extends React.ComponentPropsWithoutRef<typeof Card> {
  variant?: "blue" | "pink" | "purple";
  glowEffect?: boolean;
  hoverEffect?: boolean;
}

export function CyberCard({
  children,
  className,
  variant = "blue",
  glowEffect = false,
  hoverEffect = true,
  ...props
}: CyberCardProps) {
  const variantClasses = {
    blue: "bg-cyber-dark cyber-border",
    pink: "bg-cyber-dark cyber-border-pink",
    purple: "bg-cyber-dark border-cyber-purple",
  };

  return (
    <Card
      className={cn(
        "p-5 rounded-lg",
        variantClasses[variant],
        hoverEffect ? "transform transition-all duration-300 hover:scale-[1.02]" : "",
        glowEffect ? "hover:shadow-glow" : "",
        className
      )}
      {...props}
    >
      {children}
    </Card>
  );
}
