import React from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export interface CyberInputProps extends React.ComponentPropsWithoutRef<typeof Input> {
  variant?: "blue" | "pink" | "purple";
}

export function CyberInput({
  className,
  variant = "blue",
  ...props
}: CyberInputProps) {
  const variantClasses = {
    blue: "bg-cyber-gray border-cyber-blue cyber-border text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyber-blue",
    pink: "bg-cyber-gray border-cyber-pink cyber-border-pink text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyber-pink",
    purple: "bg-cyber-gray border-cyber-purple text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cyber-purple",
  };

  return (
    <Input
      className={cn(
        "w-full p-3",
        variantClasses[variant],
        className
      )}
      {...props}
    />
  );
}
