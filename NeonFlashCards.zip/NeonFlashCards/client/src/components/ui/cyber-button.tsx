import React from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export interface CyberButtonProps extends React.HTMLAttributes<HTMLButtonElement> {
  variant?: "blue" | "pink" | "purple";
  glowEffect?: boolean;
  disabled?: boolean;
  type?: "button" | "submit" | "reset";
  asChild?: boolean;
  size?: "default" | "sm" | "lg" | "icon";
}

export function CyberButton({
  children,
  className,
  variant = "blue",
  glowEffect = true,
  ...props
}: CyberButtonProps) {
  const variantClasses = {
    blue: "bg-cyber-dark cyber-border text-cyber-blue hover:text-white",
    pink: "bg-cyber-dark cyber-border-pink text-cyber-pink hover:text-white",
    purple: "bg-cyber-dark border-cyber-purple text-cyber-purple hover:text-white",
  };

  return (
    <Button
      className={cn(
        "relative overflow-hidden font-orbitron transition-all duration-300 cyber-btn",
        variantClasses[variant],
        glowEffect ? "hover:shadow-glow" : "",
        className
      )}
      {...props}
    >
      {children}
    </Button>
  );
}
