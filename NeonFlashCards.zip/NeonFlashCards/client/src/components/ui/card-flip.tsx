import React, { useState } from "react";
import { cn } from "@/lib/utils";

interface CardFlipProps {
  front: React.ReactNode;
  back: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export function CardFlip({ front, back, className, onClick }: CardFlipProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
    if (onClick) onClick();
  };

  return (
    <div
      className={cn(
        "flip-card h-96 w-full cursor-pointer perspective-1000",
        isFlipped ? "flipped" : "",
        className
      )}
      onClick={handleFlip}
    >
      <div className="flip-card-inner relative w-full h-full transition-transform duration-600 transform-style-preserve-3d">
        <div className="flip-card-front absolute w-full h-full backface-hidden bg-cyber-dark cyber-border rounded-lg p-8 flex flex-col items-center justify-center">
          <span className="absolute top-4 left-4 text-xs opacity-70">[TAP TO FLIP]</span>
          {front}
        </div>
        <div className="flip-card-back absolute w-full h-full backface-hidden rotate-y-180 bg-cyber-dark cyber-border-pink rounded-lg p-8 flex flex-col items-center justify-center">
          <span className="absolute top-4 left-4 text-xs opacity-70">[TAP TO FLIP]</span>
          {back}
        </div>
      </div>
    </div>
  );
}
