import React from "react";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export interface CyberSwitchProps extends React.ComponentPropsWithoutRef<typeof Switch> {
  variant?: "blue" | "pink" | "purple";
  leftLabel?: string;
  rightLabel?: string;
}

export function CyberSwitch({
  className,
  variant = "blue",
  leftLabel,
  rightLabel,
  ...props
}: CyberSwitchProps) {
  const variantClasses = {
    blue: "cyber-switch-blue",
    pink: "cyber-switch-pink",
    purple: "cyber-switch-purple",
  };

  return (
    <div className="flex items-center space-x-3">
      {leftLabel && <span className="text-sm">{leftLabel}</span>}
      <Switch
        className={cn(
          "cyber-switch",
          variantClasses[variant],
          className
        )}
        {...props}
      />
      {rightLabel && <span className="text-sm">{rightLabel}</span>}
    </div>
  );
}
