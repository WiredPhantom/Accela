import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { createContext } from "react";

export const DataContext = createContext<any>(null);

createRoot(document.getElementById("root")!).render(<App />);
