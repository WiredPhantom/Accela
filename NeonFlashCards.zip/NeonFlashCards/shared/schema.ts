import { pgTable, text, serial, integer, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  accessCode: text("access_code").notNull(),
  role: text("role", { enum: ["USER", "ADMIN"] }).default("USER").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Topics Table
export const topics = pgTable("topics", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  cardCount: integer("card_count").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastAccessed: timestamp("last_accessed"),
});

// Flashcards Table
export const flashcards = pgTable("flashcards", {
  id: serial("id").primaryKey(),
  front: text("front").notNull(),
  back: text("back").notNull(),
  topicId: integer("topic_id").notNull().references(() => topics.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define relations after all tables are declared
export const usersRelations = relations(users, ({ many }) => ({
  topics: many(topics)
}));

export const topicsRelations = relations(topics, ({ many }) => ({
  flashcards: many(flashcards)
}));

export const flashcardsRelations = relations(flashcards, ({ one }) => ({
  topic: one(topics, {
    fields: [flashcards.topicId],
    references: [topics.id]
  })
}));

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  accessCode: true,
  role: true,
});

export const insertTopicSchema = createInsertSchema(topics).pick({
  name: true,
  description: true,
});

export const insertFlashcardSchema = createInsertSchema(flashcards).pick({
  front: true,
  back: true,
  topicId: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTopic = z.infer<typeof insertTopicSchema>;
export type Topic = typeof topics.$inferSelect;

export type InsertFlashcard = z.infer<typeof insertFlashcardSchema>;
export type Flashcard = typeof flashcards.$inferSelect;
